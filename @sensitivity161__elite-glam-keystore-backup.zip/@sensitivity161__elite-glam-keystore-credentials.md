# Android Upload Keystore Credentials

These credentials are used in conjunction with your Android upload keystore file to sign your app for distribution.

## Credential Values

- Android upload keystore password: 372bbbabba8190ef6ca14140e8d4f9b3
- Android key alias: 0c800d56bb17a3d444b2ddbc1f60c2e2
- Android key password: ee5410f4dd298ccdc98c9aa7f0a934db
      